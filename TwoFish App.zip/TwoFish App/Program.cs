﻿using System;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;
using System.Text;

class Program
    {
    static void Main(string[] args)
        {
        // Step 1: Get plaintext input from user
        Console.Write("Enter the plaintext: ");
        string? inputPlaintext = Console.ReadLine();

        if (string.IsNullOrEmpty(inputPlaintext))
            {
            Console.WriteLine("Error: Plaintext cannot be null or empty.");
            return;
            }

        // Step 2: Convert plaintext to bytes
        byte[] plaintext = Encoding.UTF8.GetBytes(inputPlaintext);

        // Step 3: Generate a key (use a fixed key for simplicity)
        byte[] key = Encoding.UTF8.GetBytes("1234567890ABCDEF"); // 16 bytes for 128-bit key
        if (key.Length != 16)
            {
            Console.WriteLine("Error: Key must be 16 bytes (128 bits).");
            return;
            }

        // Step 4: Initialize Twofish engine for encryption
        TwofishEngine engine = new TwofishEngine();
        engine.Init(true, new KeyParameter(key)); // 'true' for encryption

        // Step 5: Pad the plaintext to a multiple of the block size
        int blockSize = engine.GetBlockSize(); // Typically 16 bytes for Twofish
        int paddingLength = blockSize - (plaintext.Length % blockSize);
        byte[] paddedPlaintext = new byte[plaintext.Length + paddingLength];
        Buffer.BlockCopy(plaintext, 0, paddedPlaintext, 0, plaintext.Length);
        for (int j = plaintext.Length; j < paddedPlaintext.Length; j++)
            {
            paddedPlaintext[j] = (byte)paddingLength;
            }

        // Step 6: Prepare buffer for ciphertext
        byte[] ciphertext = new byte[paddedPlaintext.Length];

        // Step 7: Encrypt the plaintext block by block
        for (int i = 0; i < paddedPlaintext.Length; i += blockSize)
            {
            engine.ProcessBlock(paddedPlaintext, i, ciphertext, i);
            }

        // Step 8: Convert and display ciphertext as a hex string
        string ciphertextHex = BitConverter.ToString(ciphertext).Replace("-", "");
        Console.WriteLine("Ciphertext (in hex): " + ciphertextHex);
        }
    }
